#!/bin/sh

EFA_VERBOSE=1
export EFA_VERBOSE
`dirname $0`/runefa.sh de.nmichael.efa.boathouse.Main $*